insert into item(id,name,price,quantity) values(1,'Ball',10,100);
insert into item(id,name,price,quantity) values(2,'Table',50,100);
insert into item(id,name,price,quantity) values(3,'Chair',20,100);
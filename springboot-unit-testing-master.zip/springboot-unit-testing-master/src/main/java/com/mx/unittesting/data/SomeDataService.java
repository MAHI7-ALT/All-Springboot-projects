package com.mx.unittesting.data;

public interface SomeDataService {

	int[] retrieveAllData();

}

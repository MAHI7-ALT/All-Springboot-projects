package com.SpringJpa.SpringJpaMapping.Entities;


import java.time.LocalDate;

import java.util.List;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;



@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long empid;
    private String empname;
    private double empsalary;
    private LocalDate dateofjoining;

    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

   @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    @OneToMany(mappedBy = "employee")
    private List<Job_history>Job_history;

    public Employee() {
    }
    
    public Employee(String empname, double empsalary, LocalDate dateofjoining) {
        this.empname = empname;
        this.empsalary = empsalary;
        this.dateofjoining = dateofjoining;
    }

    public Long getEmpid() {
        return empid;
    }
   
    public String getEmpname() {
        return empname;
    }
    public void setEmpname(String empname) {
        this.empname = empname;
    }
    public double getEmpsalary() {
        return empsalary;
    }
    public void setEmpsalary(double empsalary) {
        this.empsalary = empsalary;
    }
    public LocalDate getDateofjoining() {
        return dateofjoining;
    }
    public void setDateofjoining(LocalDate dateofjoining) {
        this.dateofjoining = dateofjoining;
    }
    public Job getJob() {
        return job;
    }
    public void setJob(Job job) {
        this.job = job;
    }
    public Department getDepartment() {
        return department;
    }
    public void setDepartment(Department department) {
        this.department = department;
    }
    public List<Job_history> getJob_history() {
        return Job_history;
    }
    public void setJob_history(List<Job_history> job_history) {
        Job_history = job_history;
    }


    
}

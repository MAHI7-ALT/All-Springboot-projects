package com.SpringJpa.SpringJpaMapping.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringJpa.SpringJpaMapping.Entities.Department;

import com.SpringJpa.SpringJpaMapping.Repositories.DepartmentRepo;

@Service
public class DepartmentService {
    @Autowired
    private DepartmentRepo departmentRepo;

    @SuppressWarnings("null")
    public Department addDept(Long deptid){

        
       // Department department=new Department("BPO");
        //departmentRepo.save (department);


        //.....for employee entity...///
       Department dept=departmentRepo.findById(deptid).get();
       return dept;
    }
 
   
    
}
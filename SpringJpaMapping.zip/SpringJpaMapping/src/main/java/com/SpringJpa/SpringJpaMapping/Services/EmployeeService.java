package com.SpringJpa.SpringJpaMapping.Services;

import java.time.LocalDate;

//import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SpringJpa.SpringJpaMapping.Entities.Department;
import com.SpringJpa.SpringJpaMapping.Entities.Employee;
import com.SpringJpa.SpringJpaMapping.Entities.Job;
import com.SpringJpa.SpringJpaMapping.Repositories.EmployeeRepo;

@Component
public class EmployeeService {
    @Autowired
    EmployeeRepo employeeRepo;
    @SuppressWarnings("null")
    // public void addEmployee(Job job, Department department){
    //     LocalDate Date=LocalDate.of(2024, 1, 13);
    //     Employee employee=new Employee("Dheeraj",30000,Date);
    //     employee.setJob(job);
    //     employee.setDepartment(department);
    //     employeeRepo.save(employee);
    // }
    public Employee addEmp(Long empid){
        Employee emp=employeeRepo.findById(empid).get();
        return emp;
    }
    
        
}


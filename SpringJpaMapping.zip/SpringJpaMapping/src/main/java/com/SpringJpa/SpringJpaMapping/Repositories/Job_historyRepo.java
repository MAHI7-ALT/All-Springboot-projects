package com.SpringJpa.SpringJpaMapping.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.SpringJpa.SpringJpaMapping.Entities.Job_history;
@Repository
public interface Job_historyRepo extends JpaRepository<Job_history,Long> {
     
}

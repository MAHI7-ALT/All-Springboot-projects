package com.SpringJpa.SpringJpaMapping.Entities;


import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long deptid;
    private String deptname;

    @OneToOne
    @JoinColumn(name = "hod")
    private Employee hod;
    
    @OneToMany( mappedBy = "department",cascade = CascadeType.ALL)
    private List<Employee> employee;
    
    public Department() {
    }
    
    public Department(String deptname) {
        this.deptname = deptname;
    }

   
    public Long getDeptid() {
        return deptid;
    }
    
    public String getDeptname() {
        return deptname;
    }
    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }
    public List<Employee> getEmployee() {
        return employee;
    }
    public void setEmployee(List<Employee> employee) {
        this.employee = employee;
    }

    public Employee getHod() {
        return hod;
    }

    public void setHod(Employee hod) {
        this.hod = hod;
    }

   


    
}

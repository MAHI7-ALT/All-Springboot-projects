package com.SpringJpa.SpringJpaMapping.Entities;

import java.time.LocalDate;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Job_history {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long job_historyId;
    private LocalDate startdate;
    private LocalDate enddate;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    
    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

    public Job_history() {
    }

    public Job_history(LocalDate startdate, LocalDate enddate) {
        this.startdate = startdate;
        this.enddate = enddate;
    }

    public LocalDate getStartdate() {
        return startdate;
    }

    public void setStartdate(LocalDate startdate) {
        this.startdate = startdate;
    }

    public LocalDate getEnddate() {
        return enddate;
    }

    public void setEnddate(LocalDate enddate) {
        this.enddate = enddate;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    
    public void setJob_historyId(Long job_historyId) {
        this.job_historyId = job_historyId;
    }
    
    
}

package com.SpringJpa.SpringJpaMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.SpringJpa.SpringJpaMapping.Entities.Department;
import com.SpringJpa.SpringJpaMapping.Entities.Employee;
import com.SpringJpa.SpringJpaMapping.Entities.Job;
import com.SpringJpa.SpringJpaMapping.Services.DepartmentService;
import com.SpringJpa.SpringJpaMapping.Services.EmployeeService;
import com.SpringJpa.SpringJpaMapping.Services.JobService;
import com.SpringJpa.SpringJpaMapping.Services.Job_historyService;



@SpringBootApplication
public class SpringJpaMappingApplication implements CommandLineRunner {
 @Autowired
 private EmployeeService employeeService;
@Autowired
private JobService jobService;
@Autowired
private DepartmentService departmentService;
@Autowired
private Job_historyService job_historyService;

  
public static void main(String[] args) {
		SpringApplication.run(SpringJpaMappingApplication.class, args);
	}

@Override
public void run(String... args) throws Exception {
	//jobService.addJob();
	//departmentService.addDept();
	///......for employee entity.....///
	// Job job = jobService.addJob(2L); 
    // Department dept = departmentService.addDept(2L); 
    // employeeService.addEmployee(job,dept);
	//......for job_history entity .....////
	Job job = jobService.addJob(2L);
	Employee employee=employeeService.addEmp(3l);
	job_historyService.addData(job,employee);
}

	
	
  


}



 package com.SpringJpa.SpringJpaMapping.Services;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringJpa.SpringJpaMapping.Entities.Employee;
import com.SpringJpa.SpringJpaMapping.Entities.Job;
import com.SpringJpa.SpringJpaMapping.Entities.Job_history;
import com.SpringJpa.SpringJpaMapping.Repositories.Job_historyRepo;

@Service
public class Job_historyService {
    @SuppressWarnings("unused")
    @Autowired
    private Job_historyRepo job_historyRepo;

    public Job_history addData(Job job ,Employee employee){
        LocalDate Date1=LocalDate.of(2024, 3, 10);
        LocalDate Date2=LocalDate.of(2024, 3, 19);
        Job_history job_history=new Job_history(Date1,Date2);
        job_history.setEmployee(employee);
        job_history.setJob(job);
        job_historyRepo.save(job_history);
        return job_history;

    }

    
}



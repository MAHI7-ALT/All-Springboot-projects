package com.SpringJpa.SpringJpaMapping.Entities;


import java.util.List;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;

@Entity
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long jobid;
    private String jobtitle;
   
    @OneToMany(mappedBy = "job")
    private List<Employee> employee;
    
    public Job() {
    }
    
    public Job(String jobtitle) {
        this.jobtitle = jobtitle;
    }

    public Long getJobid() {
        return jobid;
    }

    public String getJobtitle() {
        return jobtitle;
    }

    public void setJobtitle(String jobtitle) {
        this.jobtitle = jobtitle;
    }

    public List<Employee> getEmployee() {
        return employee;
    }

    public void setEmployee(List<Employee> employee) {
        this.employee = employee;
    }

    


    
}

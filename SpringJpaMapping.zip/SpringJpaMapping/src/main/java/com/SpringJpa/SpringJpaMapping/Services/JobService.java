package com.SpringJpa.SpringJpaMapping.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringJpa.SpringJpaMapping.Entities.Job;
import com.SpringJpa.SpringJpaMapping.Repositories.JobRepo;

@Service
public class JobService{
    @Autowired
    private JobRepo jobRepo;

    @SuppressWarnings("null")
    public  Job addJob(Long jobid){
        //Job job=new Job("Non-voice");
        //jobRepo.save(job);
        Job job=jobRepo.findById(jobid).get();
        return job;

    }

    
}    
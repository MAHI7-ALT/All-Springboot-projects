package com.SpringJpa.SpringJpaMapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}

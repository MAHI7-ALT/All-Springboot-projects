package ioc;

import java.util.List;

public interface Catalog {
     List<String> getBooks();
}

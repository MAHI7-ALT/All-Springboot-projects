package jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesRepo extends JpaRepository<Sale, Integer>{

}

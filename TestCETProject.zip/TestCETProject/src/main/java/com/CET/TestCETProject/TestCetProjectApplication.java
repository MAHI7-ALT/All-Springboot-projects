package com.CET.TestCETProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestCetProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestCetProjectApplication.class, args);
	}

}

package com.CET.TestCETProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCetProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

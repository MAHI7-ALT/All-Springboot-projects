package com.restapi.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiCrudExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}

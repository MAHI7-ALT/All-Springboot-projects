this is a product management rest API.
I have used Spring Boot in this project.

//  http://localhost:8080/products : this is URL of this project.

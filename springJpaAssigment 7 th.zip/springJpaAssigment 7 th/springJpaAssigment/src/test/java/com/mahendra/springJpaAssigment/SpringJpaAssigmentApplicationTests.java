package com.mahendra.springJpaAssigment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaAssigmentApplicationTests {

	@Test
	void contextLoads() {
	}

}

package demo.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import demo.demo.Controller.CategoryController;
import demo.demo.Controller.DepartmentController;
import demo.demo.Controller.EmployeeController;
import demo.demo.Controller.ExpenditureController;
import demo.demo.Controller.PaymentModeController;


@SpringBootApplication
public class DemoApplication implements CommandLineRunner{

	@Autowired
	CategoryController categoryController;

	@Autowired
	DepartmentController departmentController;

	@Autowired
	EmployeeController employeeController;

	@Autowired
	PaymentModeController paymentModeController;

	@Autowired
	ExpenditureController expenditureController;


	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println(".............hi.............");
		expenditureController.exPage("CAT003",0,2);
	}

}

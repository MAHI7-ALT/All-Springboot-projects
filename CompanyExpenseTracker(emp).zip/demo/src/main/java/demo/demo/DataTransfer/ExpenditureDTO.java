package demo.demo.DataTransfer;

import java.time.LocalDate;

public class ExpenditureDTO {
  
    private int id;
    private double amount;
    private LocalDate data;
    private String description;
    private String remarks;
    private String cateCode;
    private String deptCode;
    private String paymentCode;
    private String hod;


    public ExpenditureDTO() {
    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public double getAmount() {
        return amount;
    }


    public void setAmount(double amount) {
        this.amount = amount;
    }


    public LocalDate getData() {
        return data;
    }


    public void setData(LocalDate data) {
        this.data = data;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public String getRemarks() {
        return remarks;
    }


    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }


    public String getCateCode() {
        return cateCode;
    }


    public void setCateCode(String cateCode) {
        this.cateCode = cateCode;
    }


    public String getDeptCode() {
        return deptCode;
    }


    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }


    public String getPaymentCode() {
        return paymentCode;
    }


    public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
    }


    public String getHod() {
        return hod;
    }


    public void setHod(String hod) {
        this.hod = hod;
    }


    @Override
    public String toString() {
        return "ExpenditureDTO [id=" + id + ", amount=" + amount + ", data=" + data + ", description=" + description
                + ", remarks=" + remarks + ", cateCode=" + cateCode + ", deptCode=" + deptCode + ", paymentCode="
                + paymentCode + ", hod=" + hod + "]";
    }


   

    
    
 

    

}

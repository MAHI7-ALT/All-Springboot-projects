package demo.demo.Repository;



import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import demo.demo.Entity.Category;

import demo.demo.Entity.Expenditure;
import demo.demo.Entity.PaymentMode;

@Repository
public interface ExpenditureRepo extends JpaRepository<Expenditure,Integer>{

    

    List<Expenditure> findAllByCategory(Category category, Pageable pageable);

    List<Expenditure> findAllByPaymentMode(PaymentMode paymentMode,Pageable pageable);

    // Page<Expenditure> findAllByData(LocalDate starDate, LocalDate endDate, Pageable pageable);

//    Page<Expenditure> findAllExpDateBetween(LocalDate starDate,LocalDate endDate,Pageable pageable);

    Page<Expenditure> findAllByDataBetween(LocalDate startDate, LocalDate endDate, Pageable pageable);

   
    @Query("SELECT e.category.catCode, SUM(e.amount) FROM Expenditure e WHERE MONTH(e.data) = :month GROUP BY e.category.catCode")
        List<Object[]> findTotalAmountByCategoryInMonth(@Param("month") int month);

     List<Expenditure> findByDepartmentDeptCodeAndDataBetween(String deptCode ,LocalDate startDate,LocalDate endDate);

    //  List<Expenditure> findAllByAuthorizedBy(String authorizedBy);

    List<Expenditure> findAllByAuthorizeBy(String authorizeBy);

    List<Expenditure> findAllByDescriptionContaining(String keyword);

    List<Expenditure> findAllByAmountBetween(Double minAmount, Double maxAmount);
    
}

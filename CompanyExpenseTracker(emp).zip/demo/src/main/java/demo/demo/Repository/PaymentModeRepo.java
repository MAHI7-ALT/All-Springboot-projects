package demo.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import demo.demo.Entity.PaymentMode;

@Repository
public interface PaymentModeRepo extends JpaRepository<PaymentMode, String>{
    
}

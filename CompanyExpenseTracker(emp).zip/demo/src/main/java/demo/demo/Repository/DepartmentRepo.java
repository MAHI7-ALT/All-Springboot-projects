package demo.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import demo.demo.Entity.Department;
@Repository
public interface DepartmentRepo extends JpaRepository<Department, String>{

     @Query("SELECT d, SUM(e.amount) FROM Department d LEFT JOIN d.expenditures e GROUP BY d")
    List<Object[]> findDepartmentWithTotalAmount();
    
}

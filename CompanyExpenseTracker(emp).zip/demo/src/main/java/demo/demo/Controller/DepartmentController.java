package demo.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import demo.demo.DataTransfer.DepartmentDTO;
import demo.demo.Entity.Department;
import demo.demo.Entity.Employee;
import demo.demo.Repository.DepartmentRepo;
import demo.demo.Repository.EmployeeRepo;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    DepartmentRepo departmentRepo;

    @Autowired
    EmployeeRepo employeeRepo;

    // @PostMapping("/add")
    // public void addDepartment( @RequestParam("empid") int id,@RequestBody Department dept){
    //     Employee employee = employeeRepo.findById(id).get();
    //     Department department = new Department();
    //     department.setHod(employee);
    //     department.setDeptName(dept.getDeptName());
    //     department.setDeptCode(dept.getDeptCode());

    //     departmentRepo.save(department);
    // }

      @PostMapping("/add")
      @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> addDepartment(@RequestParam("empid") int id, @RequestBody Department dept) {
        try {
            Employee employee = employeeRepo.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));
            Department department = new Department();
            department.setHod(employee);
            department.setDeptName(dept.getDeptName());
            department.setDeptCode(dept.getDeptCode());
            departmentRepo.save(department);
            return ResponseEntity.ok("Department added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add department: " + e.getMessage());
        }
    }
//  @PostMapping("/add")
//     public void addExpenditure(  
//         @RequestParam("catCode") String catCode,
//         @RequestParam("deptCode") String deptCode,
//         @RequestParam("id") int id,
//         @RequestParam("payCode") String payCode, 
//         @RequestBody Expenditure exp){

//             Category category = categoryRepo.findById(catCode).get();
//             Department department = departmentRepo.findById(deptCode).get();
//             Employee employee = employeeRepo.findById(id).get();
//             PaymentMode paymentMode = paymentModeRepo.findById(payCode).get();

//             Expenditure expenditure = new Expenditure();
//             expenditure.setCategory(category);
//             expenditure.setDepartment(department);
//             expenditure.setAuthorizeBy(employee);
//             expenditure.setPaymentMode(paymentMode);

//             expenditure.setAmount(expenditure.getAmount());
//             expenditure.setRemarks(expenditure.getRemarks());
//             expenditure.setData(expenditure.getData());
//             expenditure.setDescription(expenditure.getDescription());
//             expenditureRepo.save(expenditure);
        
//     }
    public Department getDepartment(String deptCode){
        return departmentRepo.findById(deptCode).get();

    }
    // @GetMapping("/all")
    // public List<DepartmentDTO> getAllDepartments(){
    //     List<Department> departments = departmentRepo.findAll();
    //     List<DepartmentDTO> deptDto = new ArrayList<>();
    //     for(Department dept : departments){
    //         DepartmentDTO departmentDTO = new DepartmentDTO();
    //         departmentDTO.setDeptCode(dept.getDeptCode());
    //         departmentDTO.setDeptName(dept.getDeptName());
    //         departmentDTO.setEmpName(dept.getHod().getEmpName());
    //         deptDto.add(departmentDTO);
    //     }
    //     return deptDto;
        
    // }
    @GetMapping("/all")
    public ResponseEntity<List<DepartmentDTO>> getAllDepartments() {
        try {
            List<Department> departments = departmentRepo.findAll();
            List<DepartmentDTO> deptDto = new ArrayList<>();
            for (Department dept : departments) {
                DepartmentDTO departmentDTO = new DepartmentDTO();
                departmentDTO.setDeptCode(dept.getDeptCode());
                departmentDTO.setDeptName(dept.getDeptName());
                departmentDTO.setEmpName(dept.getHod().getEmpName());
                deptDto.add(departmentDTO);
            }
            return ResponseEntity.ok(deptDto);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // @PutMapping("/update")
    // public Department updateDepartment(@RequestParam("deptCode")String deptCode,@RequestBody Department dept){
    //     Department department = departmentRepo.findById(deptCode).get();
    //     department.setDeptName(dept.getDeptName());
    //     departmentRepo.save(department);
    //     return department;
    // }
    @PutMapping("/update")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> updateDepartment(@RequestParam("deptCode") String deptCode, @RequestBody Department dept) {
        try {
            Department department = departmentRepo.findById(deptCode).orElseThrow(() -> new RuntimeException("Department not found"));
            department.setDeptName(dept.getDeptName());
            departmentRepo.save(department);
            return ResponseEntity.ok("Department updated successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update department: " + e.getMessage());
        }
    }

    // @DeleteMapping("/delete/{deptCode}")
    // public void deleteDepartment(@PathVariable String deptCode){
    //     departmentRepo.deleteById(deptCode);

    // }
    @DeleteMapping("/delete/{deptCode}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> deleteDepartment(@PathVariable String deptCode) {
        try {
            departmentRepo.deleteById(deptCode);
            return ResponseEntity.ok("Department deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete department: " + e.getMessage());
        }
    }

//     @GetMapping("/departments")
// public List<Object[]> getDepartmentsWithTotalAmount() {
//     return departmentRepo.findDepartmentWithTotalAmount();
// }

@GetMapping("/departments")
public ResponseEntity<List<Object[]>> getDepartmentsWithTotalAmount() {
    try {
        List<Object[]> departmentsWithAmount = departmentRepo.findDepartmentWithTotalAmount();
        return ResponseEntity.ok(departmentsWithAmount);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
}

  @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleException(Exception e) {
        return "An error occurred: " + e.getMessage();
    }
    
}

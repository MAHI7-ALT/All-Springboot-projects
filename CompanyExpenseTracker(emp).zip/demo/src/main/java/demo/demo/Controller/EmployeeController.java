package demo.demo.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import demo.demo.Entity.Employee;
import demo.demo.Repository.EmployeeRepo;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeRepo employeeRepo;

    // @PostMapping("/add")
    // public void addEmployee(@RequestBody Employee emp){
    //     employeeRepo.save(emp);
    // }
        @PostMapping("/add")
        @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> addEmployee(@RequestBody Employee emp) {
        try {
            employeeRepo.save(emp);
            return ResponseEntity.ok("Employee added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add employee: " + e.getMessage());
        }
    }

    // public Employee getEmployeeById(int id){
    //     return employeeRepo.findById(id).get();
    // }
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(int id) {
        try {
            Employee employee = employeeRepo.findById(id).orElse(null);
            return ResponseEntity.ok(employee);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Employee>> getAllEmployee() {
        try {
            List<Employee> employees = employeeRepo.findAll();
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    //  @GetMapping("/all")
    // public List<Employee> getAllEmployee(){
    //     return employeeRepo.findAll();
    // }
    
      @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleException(Exception e) {
        return "An error occurred: " + e.getMessage();
    }
}

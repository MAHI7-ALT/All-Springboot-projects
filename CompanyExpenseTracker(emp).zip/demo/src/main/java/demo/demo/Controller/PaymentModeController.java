package demo.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import demo.demo.Entity.PaymentMode;
import demo.demo.Repository.PaymentModeRepo;

@RestController
@RequestMapping("/paymentMode")
public class PaymentModeController {

    @Autowired
    PaymentModeRepo paymentModeRepo;

    // @PostMapping("/add")
    // public void addPaymentMode(@RequestBody PaymentMode pay){
    //     paymentModeRepo.save(pay);

    // }

      @PostMapping("/add")
      @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> addPaymentMode(@RequestBody PaymentMode pay) {
        try {
            paymentModeRepo.save(pay);
            return ResponseEntity.ok("Payment mode added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add payment mode");
        }
    }

    // @GetMapping("/{id}")
    // public PaymentMode getPaymentModeById(String paycode){
    //     return paymentModeRepo.findById(paycode).get();
    // }

    @GetMapping("/{id}")
    public ResponseEntity<PaymentMode> getPaymentModeById(@PathVariable String id) {
        try {
            PaymentMode paymentMode = paymentModeRepo.findById(id).orElse(null);
            if (paymentMode != null) {
                return ResponseEntity.ok(paymentMode);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // @GetMapping("/all")
    // public List<PaymentMode> getAllPaymentMode(){
    //     return paymentModeRepo.findAll();
    // }

    @GetMapping("/all")
    public ResponseEntity<List<PaymentMode>> getAllPaymentMode() {
        try {
            List<PaymentMode> paymentModes = paymentModeRepo.findAll();
            return ResponseEntity.ok(paymentModes);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // @PutMapping("/update")
    // public PaymentMode UpdatePaymentMode(@RequestParam ("payCode") String payCode, @RequestBody PaymentMode paymentMode){
    //     PaymentMode p = paymentModeRepo.findById(payCode).get();
    //     p.setPayName(paymentMode.getPayName());
    //     p.setRemarks(paymentMode.getRemarks());
    //     paymentModeRepo.save(p);
    //     return p;
    // }

    @PutMapping("/update")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> updatePaymentMode(@RequestParam("payCode") String payCode, @RequestBody PaymentMode paymentMode) {
        try {
            PaymentMode p = paymentModeRepo.findById(payCode).orElse(null);
            if (p != null) {
                p.setPayName(paymentMode.getPayName());
                p.setRemarks(paymentMode.getRemarks());
                paymentModeRepo.save(p);
                return ResponseEntity.ok("Payment mode updated successfully");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Payment mode not found");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update payment mode");
        }
    }

    // @DeleteMapping("/delete/{payCode}")
    // public void deletePaymentMode(@PathVariable String payCode){
    //     paymentModeRepo.deleteById(payCode);
    // }
    @DeleteMapping("/delete/{payCode}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> deletePaymentMode(@PathVariable String payCode) {
        try {
            paymentModeRepo.deleteById(payCode);
            return ResponseEntity.ok("Payment mode deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete payment mode");
        }
    }
    
}

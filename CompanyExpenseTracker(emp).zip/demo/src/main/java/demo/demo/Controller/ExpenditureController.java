package demo.demo.Controller;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import demo.demo.DataTransfer.ExpenditureDTO;
import demo.demo.Entity.Category;
import demo.demo.Entity.Department;
import demo.demo.Entity.Expenditure;
import demo.demo.Entity.PaymentMode;
import demo.demo.Repository.CategoryRepo;
import demo.demo.Repository.DepartmentRepo;
import demo.demo.Repository.EmployeeRepo;
import demo.demo.Repository.ExpenditureRepo;
import demo.demo.Repository.PaymentModeRepo;

@RestController
@RequestMapping("/expinditure")
public class ExpenditureController {

    @Autowired
    ExpenditureRepo expenditureRepo;

    @Autowired
    CategoryRepo categoryRepo;

    @Autowired
    DepartmentRepo departmentRepo;

    @Autowired
    EmployeeRepo employeeRepo;

    @Autowired
    PaymentModeRepo paymentModeRepo;

    // @PostMapping("/add")
    // public void addExpenditure(  
    //     @RequestParam("catCode") String catCode,
    //     @RequestParam("deptCode") String deptCode,
    //     @RequestParam("payCode") String payCode,
    //     @RequestBody Expenditure exp){

    //         Category category = categoryRepo.findById(catCode).get();
    //         Department department = departmentRepo.findById(deptCode).get();
    //         PaymentMode paymentMode = paymentModeRepo.findById(payCode).get();

    //         Expenditure expenditure = new Expenditure();
    //         expenditure.setCategory(category);
    //         expenditure.setDepartment(department);
    //         expenditure.setAuthorizeBy(department.getHod().getEmpName());
    //         expenditure.setPaymentMode(paymentMode);

    //         expenditure.setAmount(exp.getAmount());
    //         expenditure.setRemarks(exp.getRemarks());
    //         expenditure.setData(exp.getData());
    //         expenditure.setDescription(exp.getDescription());
    //         expenditureRepo.save(expenditure);
        
    // }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<String> addExpenditure(  
    @RequestParam("catCode") String catCode,
    @RequestParam("deptCode") String deptCode,
    @RequestParam("payCode") String payCode,
    @RequestBody Expenditure exp) {
    try {
        Category category = categoryRepo.findById(catCode).orElseThrow(() -> new RuntimeException("Category not found"));
        Department department = departmentRepo.findById(deptCode).orElseThrow(() -> new RuntimeException("Department not found"));
        PaymentMode paymentMode = paymentModeRepo.findById(payCode).orElseThrow(() -> new RuntimeException("Payment mode not found"));

        Expenditure expenditure = new Expenditure();
        expenditure.setCategory(category);
        expenditure.setDepartment(department);
        expenditure.setAuthorizeBy(department.getHod().getEmpName());
        expenditure.setPaymentMode(paymentMode);

        expenditure.setAmount(exp.getAmount());
        expenditure.setRemarks(exp.getRemarks());
        expenditure.setData(exp.getData());
        expenditure.setDescription(exp.getDescription());

        expenditureRepo.save(expenditure);
        
        return ResponseEntity.ok("Expenditure added successfully");
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add expenditure: " + e.getMessage());
    }
    }


    // @GetMapping("/all")
    // public List<ExpenditureDTO>getAllExpenditure(){
    //     List<Expenditure> exp = expenditureRepo.findAll();
    //     List<ExpenditureDTO> expDto = new ArrayList<>();
    //     for(Expenditure e : exp){
    //         if(e.getAmount()!=null){
    //         ExpenditureDTO a= new ExpenditureDTO();
    //         a.setId(e.getId());
    //         a.setAmount(e.getAmount());
    //         a.setDescription(e.getDescription());
    //         a.setData(e.getData());
    //         a.setCateCode(e.getCategory().getCatCode());
    //         a.setDeptCode(e.getDepartment().getDeptCode());
    //         a.setHod(e.getAuthorizeBy());
    //         a.setPaymentCode(e.getPaymentMode().getPayCode());
    //         a.setRemarks(e.getRemarks());
    //         expDto.add(a);
    //     }
    // }
    //     return expDto;
    // }

    @GetMapping("/all")
    public ResponseEntity<List<ExpenditureDTO>> getAllExpenditure() {
     try {
        List<Expenditure> exp = expenditureRepo.findAll();
        List<ExpenditureDTO> expDto = new ArrayList<>();
        for (Expenditure e : exp) {
            if (e.getAmount() != null) {
                ExpenditureDTO a = new ExpenditureDTO();
                a.setId(e.getId());
                a.setAmount(e.getAmount());
                a.setDescription(e.getDescription());
                a.setData(e.getData());
                a.setCateCode(e.getCategory().getCatCode());
                a.setDeptCode(e.getDepartment().getDeptCode());
                a.setHod(e.getAuthorizeBy());
                a.setPaymentCode(e.getPaymentMode().getPayCode());
                a.setRemarks(e.getRemarks());
                expDto.add(a);
            }
        }
        return ResponseEntity.ok(expDto);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
    }

    // @PutMapping("/update")
    // public Expenditure updateExpenditure(@RequestParam("expId")int expId , @RequestBody Expenditure expenditure){
    //     Expenditure exp =expenditureRepo.findById(expId).get();
    //     exp.setAmount(expenditure.getAmount());
    //     exp.setRemarks(expenditure.getRemarks());
    //     exp.setDescription(expenditure.getDescription());
    //     expenditureRepo.save(exp);
    //     return exp;
    // }

    @PutMapping("/update")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Expenditure> updateExpenditure(@RequestParam("expId") int expId, @RequestBody Expenditure expenditure) {
    try {
        Expenditure exp = expenditureRepo.findById(expId).orElse(null);
        if (exp == null) {
            return ResponseEntity.notFound().build();
        }
        exp.setAmount(expenditure.getAmount());
        exp.setRemarks(expenditure.getRemarks());
        exp.setDescription(expenditure.getDescription());
        expenditureRepo.save(exp);
        return ResponseEntity.ok(exp);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
    }
    // @DeleteMapping("/delete/{Id}")
    // public void deleteExpenditure (@PathVariable int Id){
    //     expenditureRepo.deleteById(Id);
    // }

    @DeleteMapping("/delete/{Id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> deleteExpenditure(@PathVariable int Id) {
    try {
        expenditureRepo.deleteById(Id);
        return ResponseEntity.noContent().build();
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }


    // @GetMapping("/category/{categoryCode}")
    // public Page<Expenditure> getExpendituresByCategory(
    //     @RequestParam("catCode") String catCode,
    //     @RequestParam(defaultValue = "0") int page,
    //     @RequestParam(defaultValue = "5") int size 
    // ){
    //     Category category = categoryRepo.findById(catCode).orElseThrow(()-> new RuntimeException("Category not found"));
    //     PageRequest pageRequest =PageRequest.of(page, size, Sort.by("id").ascending());
    //     return expenditureRepo.findAllByCategory(category,pageRequest);
    // }
    


    // @GetMapping("/category/{catCode}")
    // public List<ExpenditureDTO> exPage(@PathVariable String catCode,@RequestParam ("pageno") int pageno,@RequestParam("num")int num){
    //     Pageable pageable = PageRequest.of(pageno, num, Sort.by("id"));
    //     Category category = categoryRepo.findById(catCode).get();
    //     System.out.println(category.toString());
    //     List<Expenditure> exp = expenditureRepo.findAllByCategory(category,pageable);
    //     // for (Expenditure expenditure : exp) {
    //     //     System.out.println(expenditure.toString());
    //     // }
    //     List<ExpenditureDTO> expDto = new ArrayList<>();
    //     for(Expenditure e: exp){
    //         ExpenditureDTO a = new ExpenditureDTO();
    //         a.setId(e.getId());
    //         a.setAmount(e.getAmount());
    //         a.setData(e.getData());
    //         a.setDescription(e.getDescription());
    //         a.setRemarks(e.getRemarks());
    //         a.setCateCode(e.getCategory().getCatCode());
    //         a.setDeptCode(e.getDepartment().getDeptCode());
    //         a.setHod(e.getAuthorizeBy());
    //         a.setPaymentCode(e.getPaymentMode().getPayCode());
    //         expDto.add(a);
    //     }
        
    //         return expDto;
    // }

    @GetMapping("/category/{catCode}")
    public ResponseEntity<List<ExpenditureDTO>> exPage(@PathVariable String catCode, @RequestParam("pageno") int pageno, @RequestParam("num") int num) {
    try {
        Pageable pageable = PageRequest.of(pageno, num, Sort.by("id"));
        Category category = categoryRepo.findById(catCode).orElseThrow(() -> new RuntimeException("Category not found"));

        List<Expenditure> exp = expenditureRepo.findAllByCategory(category, pageable);

        List<ExpenditureDTO> expDto = new ArrayList<>();
        for (Expenditure e : exp) {
            ExpenditureDTO a = new ExpenditureDTO();
            a.setId(e.getId());
            a.setAmount(e.getAmount());
            a.setData(e.getData());
            a.setDescription(e.getDescription());
            a.setRemarks(e.getRemarks());
            a.setCateCode(e.getCategory().getCatCode());
            a.setDeptCode(e.getDepartment().getDeptCode());
            a.setHod(e.getAuthorizeBy());
            a.setPaymentCode(e.getPaymentMode().getPayCode());
            expDto.add(a);
        }

        return ResponseEntity.ok(expDto);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }


    // @GetMapping("/paymentMode/{payCode}")
    // public List<ExpenditureDTO> findAllByPayment(@PathVariable String payCode, @RequestParam("pageno")int pageno,@RequestParam("num") int num){
    //     Pageable pageable = PageRequest.of(pageno, num, Sort.by("id"));

    //     PaymentMode paymentMode = paymentModeRepo.findById(payCode).get();
    //     List<Expenditure> exp2 = expenditureRepo.findAllByPaymentMode(paymentMode, pageable);
    //     List<ExpenditureDTO> expenditureDTOs = new ArrayList<>();
    //     for(Expenditure expenses : exp2){
    //         ExpenditureDTO exp = new ExpenditureDTO();
    //         exp.setId(expenses.getId());
    //         exp.setAmount(expenses.getAmount());
    //         exp.setDescription(expenses.getDescription());
    //         exp.setRemarks(expenses.getRemarks());
    //         exp.setHod(expenses.getAuthorizeBy());
    //         exp.setCateCode(expenses.getCategory().getCatCode());
    //         exp.setDeptCode(expenses.getDepartment().getDeptCode());
    //         exp.setPaymentCode(expenses.getPaymentMode().getPayCode());
    //         exp.setData(expenses.getData());
    //         expenditureDTOs.add(exp);
    //     }
    //     return expenditureDTOs;

    // }

    @GetMapping("/paymentMode/{payCode}")
    public ResponseEntity<List<ExpenditureDTO>> findAllByPayment(@PathVariable String payCode, @RequestParam("pageno") int pageno, @RequestParam("num") int num) {
    try {
        Pageable pageable = PageRequest.of(pageno, num, Sort.by("id"));

        PaymentMode paymentMode = paymentModeRepo.findById(payCode).orElseThrow(() -> new RuntimeException("Payment Mode not found"));
        List<Expenditure> exp2 = expenditureRepo.findAllByPaymentMode(paymentMode, pageable);
        List<ExpenditureDTO> expenditureDTOs = new ArrayList<>();
        for (Expenditure expenses : exp2) {
            ExpenditureDTO exp = new ExpenditureDTO();
            exp.setId(expenses.getId());
            exp.setAmount(expenses.getAmount());
            exp.setDescription(expenses.getDescription());
            exp.setRemarks(expenses.getRemarks());
            exp.setHod(expenses.getAuthorizeBy());
            exp.setCateCode(expenses.getCategory().getCatCode());
            exp.setDeptCode(expenses.getDepartment().getDeptCode());
            exp.setPaymentCode(expenses.getPaymentMode().getPayCode());
            exp.setData(expenses.getData());
            expenditureDTOs.add(exp);
        }
        return ResponseEntity.ok(expenditureDTOs);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }


    // @GetMapping("/inDates")
    // public Page<Expenditure> getAllExpendituresBteweenDates(@RequestParam ("startDate") LocalDate starDate, @RequestParam("endDate") LocalDate endDate,@RequestParam("pageno") int pageno,@RequestParam("size") int size){

    //     Pageable pageable = PageRequest.of(pageno, size, Sort.by(Sort.Order.desc("data")));
    //     Page<Expenditure> page = expenditureRepo.findAllByData(starDate,endDate,pageable);

    //     return page;
    // }

//     @GetMapping("/inDates")
// public Page<Expenditure> getAllExpendituresBetweenDates(@RequestParam("startDate") LocalDate startDate,
//                                                          @RequestParam("endDate") LocalDate endDate,
//                                                          @RequestParam("pageno") int pageno,
//                                                          @RequestParam("size") int size) {
//     Pageable pageable = PageRequest.of(pageno, size, Sort.by(Sort.Order.desc("data")));
//     return expenditureRepo.findAllByDataBetween(startDate, endDate, pageable);
// }

    @GetMapping("/inDates")
        public ResponseEntity<Page<Expenditure>> getAllExpendituresBetweenDates(@RequestParam("startDate") LocalDate startDate,
                                                                         @RequestParam("endDate") LocalDate endDate,
                                                                         @RequestParam("pageno") int pageno,
                                                                         @RequestParam("size") int size) {
    try {
        Pageable pageable = PageRequest.of(pageno, size, Sort.by(Sort.Order.desc("data")));
        Page<Expenditure> expenditures = expenditureRepo.findAllByDataBetween(startDate, endDate, pageable);
        return ResponseEntity.ok(expenditures);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }

// @GetMapping("/summary/{month}")
// public List<Object[]> getExpenseSummaryByCategory(@PathVariable int month) {
//     return expenditureRepo.findTotalAmountByCategoryInMonth(month);
// }

    @GetMapping("/summary/{month}")
    public ResponseEntity<List<Object[]>> getExpenseSummaryByCategory(@PathVariable int month) {
    try {
        List<Object[]> summary = expenditureRepo.findTotalAmountByCategoryInMonth(month);
        return ResponseEntity.ok(summary);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }


// @GetMapping("/departments/{deptCode}")
// public List<Expenditure> findAllDepartmentsBydates(@PathVariable String deptCode,@RequestParam LocalDate startDate,@RequestParam LocalDate endDate){
//     List<Expenditure> expenditures = expenditureRepo.findByDepartmentDeptCodeAndDataBetween(deptCode, startDate, endDate);
//     return expenditures;
    
// }

    @GetMapping("/departments/{deptCode}")
    public ResponseEntity<List<Expenditure>> findAllDepartmentsBydates(@PathVariable String deptCode, @RequestParam LocalDate startDate, @RequestParam LocalDate endDate) {
    try {
        List<Expenditure> expenditures = expenditureRepo.findByDepartmentDeptCodeAndDataBetween(deptCode, startDate, endDate);
        return ResponseEntity.ok(expenditures);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }
    
// @GetMapping("/getAllAuthourized")
// public List<Expenditure> getAllExpendituresByAuthourized(@RequestParam String authorizedBy){
//     List<Expenditure> expenditures = expenditureRepo.findAllByAuthorizeBy(authorizedBy);
//     return expenditures;
// }

// @GetMapping("/authorizeBy/{employeeName}")
// public List<ExpenditureDTO> getExpensesByAuthorizeBy(@PathVariable String employeeName) {
//     List<Expenditure> expenses = expenditureRepo.findAllByAuthorizeBy(employeeName);
//     List<ExpenditureDTO> expenseDTOs = new ArrayList<>();

//     for (Expenditure exp : expenses) {
//         ExpenditureDTO expDTO = new ExpenditureDTO();
//         expDTO.setId(exp.getId());
//         expDTO.setAmount(exp.getAmount());
//         expDTO.setData(exp.getData());
//         expDTO.setDescription(exp.getDescription());
//         expDTO.setRemarks(exp.getRemarks());
//         expDTO.setCateCode(exp.getCategory().getCatCode());
//         expDTO.setDeptCode(exp.getDepartment().getDeptCode());
//         expDTO.setHod(exp.getAuthorizeBy());
//         expDTO.setPaymentCode(exp.getPaymentMode().getPayCode());
//         expenseDTOs.add(expDTO);
//     }

//     return expenseDTOs;
// }

    @GetMapping("/authorizeBy/{employeeName}")
    public ResponseEntity<List<ExpenditureDTO>> getExpensesByAuthorizeBy(@PathVariable String employeeName) {
    try {
        List<Expenditure> expenses = expenditureRepo.findAllByAuthorizeBy(employeeName);
        List<ExpenditureDTO> expenseDTOs = new ArrayList<>();

        for (Expenditure exp : expenses) {
            ExpenditureDTO expDTO = new ExpenditureDTO();
            expDTO.setId(exp.getId());
            expDTO.setAmount(exp.getAmount());
            expDTO.setData(exp.getData());
            expDTO.setDescription(exp.getDescription());
            expDTO.setRemarks(exp.getRemarks());
            expDTO.setCateCode(exp.getCategory().getCatCode());
            expDTO.setDeptCode(exp.getDepartment().getDeptCode());
            expDTO.setHod(exp.getAuthorizeBy());
            expDTO.setPaymentCode(exp.getPaymentMode().getPayCode());
            expenseDTOs.add(expDTO);
        }

        return ResponseEntity.ok(expenseDTOs);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }

// @GetMapping("/descriptionContains/{keyword}")
// public List<ExpenditureDTO> getExpensesByDescriptionContains(@PathVariable String keyword) {
//     List<Expenditure> expenses = expenditureRepo.findAllByDescriptionContaining(keyword);
//     List<ExpenditureDTO> expenseDTOs = new ArrayList<>();

//     for (Expenditure exp : expenses) {
//         ExpenditureDTO expDTO = new ExpenditureDTO();
//         expDTO.setId(exp.getId());
//         expDTO.setAmount(exp.getAmount());
//         expDTO.setData(exp.getData());
//         expDTO.setDescription(exp.getDescription());
//         expDTO.setRemarks(exp.getRemarks());
//         expDTO.setCateCode(exp.getCategory().getCatCode());
//         expDTO.setDeptCode(exp.getDepartment().getDeptCode());
//         expDTO.setHod(exp.getAuthorizeBy());
//         expDTO.setPaymentCode(exp.getPaymentMode().getPayCode());
//         expenseDTOs.add(expDTO);
//     }

//     return expenseDTOs;
// }

    @GetMapping("/descriptionContains/{keyword}")
    public ResponseEntity<List<ExpenditureDTO>> getExpensesByDescriptionContains(@PathVariable String keyword) {
    try {
        List<Expenditure> expenses = expenditureRepo.findAllByDescriptionContaining(keyword);
        List<ExpenditureDTO> expenseDTOs = new ArrayList<>();

        for (Expenditure exp : expenses) {
            ExpenditureDTO expDTO = new ExpenditureDTO();
            expDTO.setId(exp.getId());
            expDTO.setAmount(exp.getAmount());
            expDTO.setData(exp.getData());
            expDTO.setDescription(exp.getDescription());
            expDTO.setRemarks(exp.getRemarks());
            expDTO.setCateCode(exp.getCategory().getCatCode());
            expDTO.setDeptCode(exp.getDepartment().getDeptCode());
            expDTO.setHod(exp.getAuthorizeBy());
            expDTO.setPaymentCode(exp.getPaymentMode().getPayCode());
            expenseDTOs.add(expDTO);
        }

        return ResponseEntity.ok(expenseDTOs);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }

// @GetMapping("/amountBetween/{minAmount}/{maxAmount}")
// public List<ExpenditureDTO> getExpensesByAmountBetween(@PathVariable Double minAmount, @PathVariable Double maxAmount) {
//     List<Expenditure> expenses = expenditureRepo.findAllByAmountBetween(minAmount, maxAmount);
//     List<ExpenditureDTO> expenseDTOs = new ArrayList<>();

//     for (Expenditure exp : expenses) {
//         ExpenditureDTO expDTO = new ExpenditureDTO();
//         expDTO.setId(exp.getId());
//         expDTO.setAmount(exp.getAmount());
//         expDTO.setData(exp.getData());
//         expDTO.setDescription(exp.getDescription());
//         expDTO.setRemarks(exp.getRemarks());
//         expDTO.setCateCode(exp.getCategory().getCatCode());
//         expDTO.setDeptCode(exp.getDepartment().getDeptCode());
//         expDTO.setHod(exp.getAuthorizeBy());
//         expDTO.setPaymentCode(exp.getPaymentMode().getPayCode());
//         expenseDTOs.add(expDTO);
//     }

//     return expenseDTOs;
// }

    @GetMapping("/amountBetween/{minAmount}/{maxAmount}")
    public ResponseEntity<List<ExpenditureDTO>> getExpensesByAmountBetween(@PathVariable Double minAmount, @PathVariable Double maxAmount) {
    try {
        List<Expenditure> expenses = expenditureRepo.findAllByAmountBetween(minAmount, maxAmount);
        List<ExpenditureDTO> expenseDTOs = new ArrayList<>();

        for (Expenditure exp : expenses) {
            ExpenditureDTO expDTO = new ExpenditureDTO();
            expDTO.setId(exp.getId());
            expDTO.setAmount(exp.getAmount());
            expDTO.setData(exp.getData());
            expDTO.setDescription(exp.getDescription());
            expDTO.setRemarks(exp.getRemarks());
            expDTO.setCateCode(exp.getCategory().getCatCode());
            expDTO.setDeptCode(exp.getDepartment().getDeptCode());
            expDTO.setHod(exp.getAuthorizeBy());
            expDTO.setPaymentCode(exp.getPaymentMode().getPayCode());
            expenseDTOs.add(expDTO);
        }

        return ResponseEntity.ok(expenseDTOs);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }

// @GetMapping("/categories")
// public List<Category> getAllCategories() {
//     return categoryRepo.findAll();
// }
    @GetMapping("/categories")
    public ResponseEntity<List<Category>> getAllCategories() {
    try {
        List<Category> categories = categoryRepo.findAll();
        return ResponseEntity.ok(categories);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }


}

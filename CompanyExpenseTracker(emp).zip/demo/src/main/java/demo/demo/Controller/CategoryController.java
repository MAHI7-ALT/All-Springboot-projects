package demo.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import demo.demo.Entity.Category;
import demo.demo.Repository.CategoryRepo;

@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    CategoryRepo categoryRepo;

    // @PostMapping("/add")
    // public Category addCategory(@RequestBody Category cat){
    //     return categoryRepo.save(cat);
    // }

       @PostMapping("/add")
       @PreAuthorize("hasRole('ADMIN')")
        public ResponseEntity<Category> addCategory(@RequestBody Category cat) {
        try {
            Category savedCategory = categoryRepo.save(cat);
            return ResponseEntity.ok(savedCategory);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        }

    // @GetMapping("/{id}")
    // public Category getCategoryById(String code){
    //     return categoryRepo.findById(code).get();
    // }
       @GetMapping("/{code}")
       
        public ResponseEntity<?> getCategoryById(@PathVariable String code) {
        try {
            Category category = categoryRepo.findById(code).orElse(null);
            if (category != null) {
                return ResponseEntity.ok(category);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("USER NOT FOUND");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        }

    // @PutMapping("/update")
    // public Category updateCattegory(@RequestParam("catCode")String catCode, @RequestBody Category cat){
    //     Category category = categoryRepo.findById(catCode).get();
    //     category.setCatName(cat.getCatName());
    //     categoryRepo.save(category) ;
    //     return category; 

    // }

       @PutMapping("/update/{catCode}")
       @PreAuthorize("hasRole('ROLE_ADMIN')")
       public ResponseEntity<Category> updateCategory(@PathVariable String catCode, @RequestBody Category cat) {
        try {
            Category category = categoryRepo.findById(catCode).orElse(null);
            if (category != null) {
                category.setCatName(cat.getCatName());
                Category updatedCategory = categoryRepo.save(category);
                return ResponseEntity.ok(updatedCategory);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        }

    // @DeleteMapping("/delete/{catCode}")
    // public void deleteCategory(@PathVariable String catCode){
    //     categoryRepo.deleteById(catCode);
    //     // System.out.println(catCode);
    // }


       @DeleteMapping("/delete/{catCode}")
       @PreAuthorize("hasRole('ROLE_ADMIN')")
       public ResponseEntity<Void> deleteCategory(@PathVariable String catCode) {
        try {
            categoryRepo.deleteById(catCode);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        }

    // @GetMapping("/all")
    // public List<Category> getAllCategory(){
    //     return categoryRepo.findAll();
    // }


        @GetMapping("/all")
        public ResponseEntity<List<Category>> getAllCategories() {
        try {
            List<Category> categories = categoryRepo.findAll();
            return ResponseEntity.ok(categories);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        }

//     @GetMapping("/categories")
// public List<Object[]> getCategoriesWithTotalAmount() {
//     return categoryRepo.findCategoryWithTotalAmount();
// }
    
        @GetMapping("/categories")
        @PreAuthorize("hasRole('ROLE_ADMIN')")
        public ResponseEntity<List<Object[]>> getCategoriesWithTotalAmount() {
        try {
            List<Object[]> categoriesWithAmount = categoryRepo.findCategoryWithTotalAmount();
            return ResponseEntity.ok(categoriesWithAmount);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleException(Exception e) {
        return "An error occurred: " + e.getMessage();
    }
}

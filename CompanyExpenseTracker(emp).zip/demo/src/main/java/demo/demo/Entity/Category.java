package demo.demo.Entity;

import java.util.List;

// import com.fasterxml.jackson.annotation.JsonIdentityReference;
// import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Category {

    @Id
    private String catCode;

    private String catName;

    @JsonIgnore
    @OneToMany(mappedBy = "category")
    private List<Expenditure> expenditures;

    public Category() {
    }

    public Category(String catCode, String catName) {
        this.catCode = catCode;
        this.catName = catName;
    }

    public String getCatCode() {
        return catCode;
    }

    public void setCatCode(String catCode) {
        this.catCode = catCode;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public List<Expenditure> getExpenditures() {
        return expenditures;
    }

    public void setExpenditures(List<Expenditure> expenditures) {
        this.expenditures = expenditures;
    }

    @Override
    public String toString() {
        return "Category [catCode=" + catCode + ", catName=" + catName + "]";
    }

    
    
    
}

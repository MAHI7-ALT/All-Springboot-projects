package demo.demo.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Department {

    @Id
    private String deptCode;

    private String deptName;

    @OneToOne
    @JsonIgnore
    private Employee hod;

    @JsonIgnore
    @OneToMany(mappedBy = "department")
    private List<Expenditure> expenditures;

    public Department() {
    }

    public Department(String deptCode, String deptName, Employee hod) {
        this.deptCode = deptCode;
        this.deptName = deptName;
        this.hod = hod;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Employee getHod() {
        return hod;
    }

    public void setHod(Employee hod) {
        this.hod = hod;
    }

    public List<Expenditure> getExpenditures() {
        return expenditures;
    }

    public void setExpenditures(List<Expenditure> expenditures) {
        this.expenditures = expenditures;
    }

    @Override
    public String toString() {
        return "Department [deptCode=" + deptCode + ", deptName=" + deptName + "]";
    }

    
    
}

package demo.demo.Entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Expenditure {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private Double amount;

    private String remarks;

    private LocalDate data;

    private String description;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "cat_code")
    private Category category;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "dept_code")
    private Department department;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "payment_mode")
    private PaymentMode paymentMode;

    private String authorizeBy;

    public Expenditure() {
    }

    public Expenditure(Double amount, String remarks, LocalDate data, String description, Category category,
            Department department, PaymentMode paymentMode, String authorizeBy) {
        this.amount = amount;
        this.remarks = remarks;
        this.data = data;
        this.description = description;
        this.category = category;
        this.department = department;
        this.paymentMode = paymentMode;
        this.authorizeBy = authorizeBy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getAuthorizeBy() {
        return authorizeBy;
    }

    public void setAuthorizeBy(String authorizeBy) {
        this.authorizeBy = authorizeBy;
    }

    @Override
    public String toString() {
        return "Expenditure [id=" + id + ", amount=" + amount + ", remarks=" + remarks + ", data=" + data
                + ", description=" + description + ", category=" + category + ", department=" + department
                + ", paymentMode=" + paymentMode + ", authorizeBy=" + authorizeBy + "]";
    }

    
    
    


}

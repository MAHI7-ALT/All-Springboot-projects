package demo.demo.Entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class PaymentMode {

    @Id
    private String payCode;

    private String payName;

    private String remarks;

    @OneToMany(mappedBy = "paymentMode")
    private List<Expenditure>expenditures;

    

    public PaymentMode() {
    }

    public PaymentMode(String payCode, String payName, String remarks) {
        this.payCode = payCode;
        this.payName = payName;
        this.remarks = remarks;
    }

    public String getPayCode() {
        return payCode;
    }


    public String getPayName() {
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "PaymentMode [payCode=" + payCode + ", payName=" + payName + ", remarks=" + remarks + "]";
    }

    


    

}
